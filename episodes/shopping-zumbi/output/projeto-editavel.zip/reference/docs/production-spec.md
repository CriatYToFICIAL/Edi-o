# Especificação de produção

## Matriz de planos

Para cada bloco narrado, escolha um plano primário e uma função. Não ilustre substantivos de forma decorativa; mostre causalidade.

| Plano | Quando usar | Movimento recomendado | Texto |
|---|---|---|---|
| Geral de lugar | Estabelecer posição, distância, acesso | Pan leve ou mudança de luz | Nenhum ou sinal do local |
| Personagem + obstáculo | Decisão e consequência | Caminhada, olhar, braço, porta | Palavra de ênfase opcional |
| Detalhe de objeto | Chave, relógio, trava, água, nota | Escala 1,00→1,05, giro curto, pulso | Rótulo próprio do objeto |
| Diagrama | Quantidade, comparação, mecanismo | Elementos entram em ordem da fala | Número e legenda curta |
| Regra/cartaz | Nova política, mudança moral | Aparição simples ou corte seco | Uma frase curta |
| Cartão temporal | Salto de dia ou capítulo | Corte seco, 0,5–1,5 s | `DIA N` ou equivalente |
| Revelação | Consequência inesperada | Segurar quadro, mostrar depois | Evitar texto explicativo antes da imagem |

## Padrões de arte sugeridos

Estas medidas são parâmetros de criação para manter consistência; não são medições certificadas do arquivo fonte.

- **Canvas mestre:** 1280×720, 16:9, 30 fps. Para protótipo, 960×540 e 24 fps. Renderize a 2× e reduza se o orçamento permitir, para contornos limpos.
- **Zona segura:** 5% lateral, 7% vertical; legenda de palavra no terço inferior, preferencialmente entre 77% e 88% da altura. Não cobrir mão, objeto decisivo ou rosto.
- **Linha:** 3–5 px para figura média em 1280×720; 1–3 px para detalhes distantes. Desenho ligeiramente irregular, mantendo silhueta estável. Não aplicar ruído aleatório por frame, pois causa cintilação.
- **Protagonista:** cabeça 0,28–0,34 da altura total; torso 0,28–0,38; pernas 0,25–0,33. Um sinal visual reconhecível mesmo em 100 px de altura. Mínimo de estados: neutro, alerta, decidido; frente, 3/4 e perfil se a história pedir.
- **Paleta base sugerida:** tinta `#2A241F`, papel `#F7E5C8`, noite `#34354B`, violeta `#6D5375`, teal `#356C69`, acento quente `#D4A44A`. Cada projeto pode redefinir os acentos para possuir identidade própria. Reserve a cor mais saturada para foco ou ameaça.
- **Cenário:** organize em camadas `céu/fundo`, `arquitetura`, `móveis`, `personagens`, `objetos interativos`, `luz`, `tipografia`. Armazene planta simples para preservar lados das portas e trajetos entre cenas.
- **Luz:** separação de planos pelo valor tonal; vinheta moderada em cenas noturnas; cartões de informação sem vinheta pesada. A fonte luminosa deve existir no ambiente ou ser assumida como recurso gráfico.
- **Tipografia:** família sans bold para títulos; frases de cartões com 4–10 palavras, número principal muito legível. Para legendas cinéticas, uma a três palavras por vez; duração conforme áudio, usualmente 0,18–0,8 s por palavra, com mínimo de 3 frames. Evite entregar palavras futuras antes da voz.

## Tempo e animação

- Narrar primeiro e temporizar os cortes depois. Ritmo inicial de planejamento: uma troca visual relevante a cada 2–7 s, com planos mais longos quando há revelação ou diagramas. Isto é faixa editorial sugerida, não medida da referência.
- Segurar poses por múltiplos frames é aceitável. Anime apenas a variável necessária para comunicar a frase: posição, escala, orientação, luz, porta ou contagem. Caminhada simples: ciclo de 8–12 poses em 0,6–1,0 s; corrida: 0,35–0,6 s. Use easing na câmera e linearidade onde sugere mecanismo.
- Para mudança de luz, anime primeiro a causa (interruptor, energia, lanterna) e depois o efeito no cenário. Som pode antecipar a imagem por 2–6 frames; registre essa escolha no storyboard.
- Para infográficos, faça o número surgir junto à palavra correspondente. Sequencie ícones em vez de mostrar tudo de uma vez.
- Corte após completar a informação visual crucial. Em suspense, mantenha o plano 0,3–1,0 s após a frase antes da revelação, se a música e a voz permitirem.

## Áudio e sincronização

1. Grave voz mono limpa, preferencialmente 48 kHz / 24 bit na captação. Defina ritmo, pausas e ênfases na leitura. Use a transcrição somente como texto; não como relógio.
2. Crie `words.json` com objetos `{text,start,end}` ancorados no áudio. Valide ouvindo 0:00–0:30, transições de capítulo, trechos de ação e fecho. Palavra na tela entra no mesmo frame da fala ou até dois frames depois; evite antecipação.
3. Escolha palavras de ação ou virada, não conectivos. Encadeie no máximo 1–3 palavras em cada cue. Para frases longas, use cartões legíveis, não legendas cinéticas.
4. Música: cama discreta que deixa a voz inteligível; aumente tensão antes de revelações e reduza em informação essencial. Efeitos ligados a causa concreta: porta, passo, metal, energia, objeto. Não há medição de LUFS verificável no arquivo fornecido; defina a meta conforme plataforma e faça leitura final de loudness no render.
5. No mix final, voz à frente, sem clipping; exporte áudio AAC 48 kHz ou preserve frequência do master. Faça revisão com fones e alto-falante simples.

## Estrutura de dados e código

`examples/observatory.json` contém `duration`, `fps`, `width`, `height`, `palette`, `character`, `shots` e `captions`. Planos devem cobrir `[0,duration)` sem lacunas. `character.headwear` aceita `beanie`, `cap`, `hood` e `none`; cores de roupa, acessório e rosto são configuráveis. `scripts/render.py` desenha um personagem e seis layouts próprios; funciona como motor de prova. Para produção longa, adicione funções em `SCENES` e leia parâmetros específicos de cada plano. Não duplique um fundo por frame: gere camadas vetoriais ou caches e transforme apenas as partes móveis. Use ID estável para objetos em retornos.

### Exemplo de storyboard de 12 s

| Tempo | Voz proposta | Visual | Ação |
|---|---|---|---|
| 0–3 | “Às duas, o observatório perdeu contato.” | Exterior noturno | Luz da fachada pulsa; local estabelecido |
| 3–6 | “Oito monitores mostraram a mesma estrela.” | Sala de controle | Oito telas tornam o detalhe visual mensurável |
| 6–9 | “Você ouviu três batidas no corredor.” | Corredor | Personagem se aproxima; porta continua fechada |
| 9–12 | “A regra era simples: escutar, contar, mover.” | Cartão | Três símbolos entram como plano mental |

## Controle de qualidade

- Um espectador compreende em que lugar está, o que ameaça o protagonista e por que a solução tem custo?
- Cada retorno ao mesmo cenário preserva porta, objetos e percurso?
- A palavra em tela coincide com o áudio correspondente? Cartões entram antes ou no momento da explicação?
- Cores e traços se mantêm entre planos, sem cintilação nem alteração acidental de proporção?
- Números têm fonte verificada ou indicação de ficção? O fecho devolve significado ao início?
- Vídeo final: formato e duração corretos, primeiro e último frame íntegros, sem tela preta inesperada, áudio audível e sem clipping.

