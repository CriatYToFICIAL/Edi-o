# Caderno de evidências das referências

## Escopo observado

- Vídeo fornecido: `Zombie Outbreak: 30 Days Locked Inside a Supermarket`, arquivo H.264 1280×720, 30 fps, AAC estéreo 44,1 kHz, duração 640,467 s. A análise visual cobriu quadros de todo o intervalo em amostras a cada 5 s, além de quatro imagens fornecidas nesta conversa e da captura do canal. Amostragem não prova movimentos entre quadros; observações de movimento abaixo se baseiam em mudanças visíveis entre amostras e em planos inspecionados.
- Transcrição fornecida: texto com seis capítulos e marcas aproximadas. Inclui ruídos de reconhecimento, como `Isisle`, marcas `0:088 segundos` e indicações `[music]`. O conteúdo foi lido integralmente; as marcas servem para localizar trechos, não para sincronizar palavras.
- Contagem exploratória do arquivo: 1.674 tokens alfabéticos brutos, incluindo cabeçalhos e marcadores, em aproximadamente 10 min 40 s; 28 marcações `[music]`. Isso sugere narração densa, mas não constitui taxa de fala limpa nem mapa de mixagem.
- Imagem do canal: banner, avatar e quatro miniaturas visíveis, com contraste `DAY 1 / DAY 30`. Dez vídeos constam no cabeçalho, mas só quatro títulos foram fornecidos. Não há base para afirmar detalhes dos outros seis.

## Linha narrativa verificada

| Tempo aproximado | Função dramática | Tratamento visual observado na amostragem |
|---|---|---|
| 0:00–0:56 | Porta automática, visitante anormal, gerente sai, protagonista fica só | Fachada, interior, detalhe de leite, monitores, palavras de ênfase na base |
| 0:56–2:05 | Problema 1: vidro, cortina, estoque, falta de energia | Cartões claros com diagrama e números; retorno ao corredor e à entrada |
| 2:05–3:56 | Porta de emergência, chaves, escuridão, decomposição, freezer, telhado | Depósito, chaves diagramadas, luzes apagando, cartão de segurança alimentar, vista de cobertura |
| 3:56–5:39 | Mortos repetem hábitos, nova rotina, água, Dana, energia volta | Multidão, regra em papel, infográfico de banheiro, estacionamento, tela de dia |
| 5:39–7:05 | Corrida ao disjuntor, pressão na cortina, barreira e relógio | Painel, fachada, silhuetas, comparação de pesos, objeto isolado, lançamentos |
| 7:05–8:56 | Sobreviventes, negociação pelo telhado, retorno de Dana, aviso | Caminhonete, depósito, balcão de troca, cartão de regra emendado, bilhete |
| 8:56–10:31 | Resgate, plano dos relógios, fuga, inventário e fecho circular | Escada, relógios multiplicados, multidão desvia, cartão `DAY 30`, inventário, retorno ao motivo da chave |

## Narrativa: mecanismos observados

1. **Voz em segunda pessoa.** “You” põe o público no lugar do funcionário. A informação vem na ordem em que ele a descobre.
2. **Concretude operacional.** Horários, quantidades, corredores, portas, peso, tempo de energia e estoque dão forma ao problema. Alguns números dependem da ficção e precisam de checagem em obras novas.
3. **Problemas numerados e soluções imperfeitas.** Vidro, alimentos perecíveis, cortina e pessoas vivas surgem em sequência; cada solução cria uma necessidade posterior.
4. **Refrão com evolução.** “New store policy” e “Nobody gets in” reaparecem; a regra é alterada quando o protagonista deixa outra pessoa entrar pelo telhado. O final mede a mudança humana com um inventário.
5. **Plantio e retorno.** A chave quebrada, Dana, a areia de gato, os relógios e o estoque voltam com nova função. O fecho retoma Dana e o turno.
6. **Suspense por atraso curto.** Ex.: “A magnet needs power”; pausa antes da porta abrir. “The dead do not knock”; em seguida, revelam-se os vivos. O texto não exige um susto visual a cada frase.
7. **Humor seco em meio à tensão.** O trabalho de varejo e os “clientes difíceis” dão unidade ao tema do supermercado.

## Visual: características observadas

- Tela horizontal 16:9; desenho 2D com contorno marrom muito escuro, preenchimentos planos e sombras suaves. Linhas têm discreta irregularidade visual; fundos são mais detalhados que rostos.
- Personagens magros: cabeça circular grande em relação ao torso, membros como linhas grossas, olho e boca reduzidos a poucos sinais. Boné vermelho e avental verde identificam o protagonista original da referência. A presente skill usa outra silhueta, roupa e cores.
- Geometria arquitetônica com perspectiva frontal/um ponto. As prateleiras criam profundidade; janelas e portas definem barreiras visuais. O mesmo espaço retorna sob estados diferentes de luz e perigo.
- Noite: azul, violeta e cinza de baixa saturação; pontos quentes em janelas, lâmpadas, olhos de luz e sinais. Interior claro: bege e cinza quente. Cartões de informação: creme com tipografia escura e ícones simplificados.
- Controles visuais: vinheta de borda, focos de lanterna, halos de luminárias, mudança de exposição na volta da energia, multidões simplificadas em camadas.
- Tipografia em duas funções: títulos/diagramas em caixa alta geométrica e negrito; palavra curta da narração em base central, escura ou clara com brilho/contorno. Na amostra de 5 s, a palavra destacada mudava frequentemente enquanto a composição da cena se mantinha.
- Planos observados: geral externo, médio de personagem, close de rosto/objeto, diagrama em fundo vazio, cartaz de política, cartão temporal e retorno ao geral. Predominam cortes diretos; não foi identificada uma transição de efeito obrigatória.

## Movimento: inferência delimitada

Quadros espaçados mostram boca/olhar simples, caminhada, corrida, carros, portas, empilhadeiras/objetos, multidão e variações de iluminação, além de deslocamentos de câmera ou reenquadramentos pontuais. A amostragem indica animação seletiva sobre fundos persistentes. Ela não mede cadência exata de keyframes, curvas de easing, número de desenhos por segundo nem sincronização labial fonema a fonema. As cadências em `production-spec.md` são metas de implementação propostas, não medidas atribuídas ao canal.

## Títulos e embalagem

Os quatro títulos visíveis compartilham `Zombie Outbreak: 30 Days` e variam o local e o confinamento: shopping, prisão, escola e supermercado. A miniatura antecipa a progressão `DAY 1 / DAY 30`, com mudança de luz e de ameaça. A captura também mostra 9,41 mil inscritos e contagens de visualização datadas naquele momento; não fornecem dados de retenção, CTR ou produção.

