---
name: illustrated-survival-episodes
description: Planeja, desenha, anima e renderiza episódios originais de sobrevivência ilustrada com narração em segunda pessoa, cenários recorrentes, diagramas e legendas sincronizadas.
---

# Illustrated Survival Episodes

Use esta skill quando o usuário pedir um vídeo narrativo ilustrado no sistema visual analisado nas referências desta pasta. Leia `docs/reference-analysis.md` e `docs/production-spec.md` antes de escrever um roteiro. Use personagens, histórias, cenário, arte e marca originais para cada nova série. A referência serve como gramática audiovisual; não reutilize frames, falas, personagem ou marca do canal.

## Contrato de entrada

Colete ou infira: tema, duração, idioma, público, formato (padrão 16:9), voz disponível, destino do arquivo e restrições factuais. Se o pedido for, por exemplo, “Crie um vídeo animado de 4 minutos sobre [TEMA] utilizando nossa SKILL”, prossiga com 1280×720, 30 fps, narração em português, uma história original em segunda pessoa e exportação MP4 H.264/AAC. Informe quaisquer dependências ausentes só quando impedirem a entrega.

## Fluxo obrigatório

1. **Premissa e regras:** formule em uma frase o lugar, a restrição e o objetivo de tempo. Liste 3–5 problemas causais específicos do lugar e um custo para cada solução. Defina uma regra que voltará modificada no desfecho.
2. **Roteiro:** escreva 130–160 palavras narradas por minuto como ponto de partida, depois ajuste ao áudio real. Abra com perigo e detalhe concreto nos primeiros 15 s; introduza o protagonista e a restrição até 45 s. Agrupe em capítulos que alterem a situação. Cada bloco deve conter ação, consequência e nova dúvida. Feche retomando um elemento plantado no início.
3. **Checagem factual:** para fatos físicos, logísticos ou médicos, registre fonte ou marque como ficção. Não replique números vistos na referência como se fossem fatos universais. O perigo dramático deve decorrer das regras estabelecidas.
4. **Narração primeiro:** grave ou sintetize a voz. Limpe ruído, equalize e normalize. Gere marcações de palavra a partir do áudio com alinhamento forçado, ou ajuste manualmente. A transcrição fornecida na referência tem marcas irregulares e erros de reconhecimento; não serve como timecode de precisão.
5. **Storyboard temporal:** para cada trecho de voz, escolha função visual: `lugar`, `ação`, `detalhe`, `diagrama`, `regra`, `marcador de tempo` ou `revelação`. Anote início/fim, elemento em foco, ação, câmera, iluminação, texto e efeito sonoro. Faça os cortes nos limites de ideias, não em intervalos arbitrários.
6. **Design:** crie um personagem modular, silhueta reconhecível e 3 expressões mínimas. Crie mapas dos ambientes que possam ser revisitados. Defina sinais, objetos e cores de perigo próprios. Veja `docs/production-spec.md`.
7. **Animatic:** monte quadros temporizados com áudio antes da arte final. Verifique que cada objeto mostrado corresponde ao que se narra naquele instante ou prepara a próxima frase.
8. **Animação e edição:** use movimento com função: caminhar, olhar, abrir/fechar, revelar, contar, aproximar. Misture planos amplos, médios, close de objeto e infográficos. Alterne densidade visual após sequências carregadas. Legendas cinéticas destacam palavras decisivas; não transcreva tudo sobre a cena.
9. **Render e revisão:** renderize MP4, assista integralmente, confira entrada/saída de legendas, legibilidade, continuidade de objetos, clipping, áudio e duração. Corrija antes de entregar.

## Implementação disponível

`scripts/render.py` é um motor mínimo funcional com seis famílias de cena: exterior, sala de controle, corredor, diagrama, regra e cartão temporal. Ele renderiza personagem e cenários por código, movimento simples, vinheta, legendas temporizadas, cortes e MP4. `examples/observatory.json` mostra o contrato da linha do tempo. Execute:

```bash
python scripts/render.py examples/observatory.json --out demo.mp4 --poster poster.png
```

Para áudio próprio:

```bash
python scripts/render.py examples/observatory.json --audio narracao.wav --out episodio.mp4
```

`--audio` pressupõe áudio final alinhado ao tempo zero do JSON. Cada `caption` tem `start`, `end` e `text`; o texto deve caber em até 30 caracteres. O renderizador valida lacunas entre planos, duração, tipos de cena e limites de legendas. Sem `--audio`, o protótipo gera áudio silencioso. Para um novo episódio de produção, expanda os módulos de cena do código e troque personagem, cenários e cores conforme o roteiro. O exemplo demonstra a arquitetura e uma prova de renderização; uma produção de quatro minutos exige mais layouts e direção de arte para manter variedade.

## Critérios de saída

Entregue roteiro, mapa de cenas, trilha de legendas temporizadas, assets originais, MP4 final e um registro de revisão. A identidade deve ser reconhecível pela linguagem de ilustração, alternância entre cena e diagrama, causalidade do roteiro e sincronização, sem depender de copiar elementos exclusivos da referência.

