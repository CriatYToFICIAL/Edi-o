# Shopping • 30 dias

Produção original baseada no áudio enviado pelo usuário (381,727 s) e na SKILL `illustrated-survival-episodes` criada nesta conversa. Referência artística: o vídeo e os quadros fornecidos de sobrevivência zumbi ilustrada.

## Arquivos

- `source/narracao.mp3`: voz original.
- `work/timeline.json`: planos e destaques temporizados.
- `scripts/film.py`: desenho e animação determinística dos ambientes, personagens, iluminação e câmera.
- `scripts/plan.py`: mapa de montagem derivado da narração.
- `scripts/sound.py`: ambiência e efeitos procedurais originais.
- `output/shopping-zumbi-final.mp4`: primeira versão completa com mixagem.

## Reproduzir

Requer Python 3, Pillow, NumPy, SciPy e FFmpeg. Os utilitários de composição da SKILL original foram incluídos em `scripts/skill_render.py`. Os cenários do shopping e o elenco foram desenhados neste projeto.

```sh
python scripts/plan.py
python scripts/film.py
python scripts/sound.py
sh scripts/mix.sh
```

São usados planos amplos e detalhes, cores noturnas com acentos quentes, diagramas em papel creme, animação seletiva e destaques de frases. A transcrição automática em `work/` serviu à localização de frases e tem erros de reconhecimento; a voz original é a fonte definitiva. O exemplo anterior do observatório não foi usado como cenário deste episódio.
