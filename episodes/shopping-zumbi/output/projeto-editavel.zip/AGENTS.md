# Shopping: sobrevivência ilustrada

Este projeto usa `/workspace/animated-survival-skill/SKILL.md`, com os documentos de referência nela indicados, e a narração original em `source/narracao.mp3`. O conteúdo é sobrevivência zumbi em um shopping. O protagonista é tratado como “você”. Davi, Marta, Lia e Rui são personagens presentes no áudio. As Skills do canal de caderno narrativo não se aplicam a este projeto.

Leia a narração e a timeline antes de modificar cenas. Preserve o arquivo de voz original. Não acrescente acontecimentos que não estejam narrados. A animação é determinística e a linha do tempo usa segundos absolutos do áudio.
