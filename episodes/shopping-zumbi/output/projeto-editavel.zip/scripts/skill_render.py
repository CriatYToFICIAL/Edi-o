#!/usr/bin/env python3
"""Render an original illustrated survival episode from a timed JSON shot list.

Dependencies: Pillow and FFmpeg. No reference artwork is copied into the output.
"""
import argparse
import functools
import json
import math
import subprocess
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageFilter


INK = "#2a241f"
CREAM = "#f7e5c8"
TEAL = "#356c69"
GOLD = "#d4a44a"
PURPLE = "#6d5375"
SLATE = "#34354b"
COAT = GOLD
HAT = PURPLE
FACE = "#f3eadf"
HEADWEAR = "beanie"
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_REG = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"


def font(size, bold=True):
    return ImageFont.truetype(FONT if bold else FONT_REG, size)


def text_center(draw, box, label, size, fill=INK, bold=True):
    draw.text(((box[0] + box[2]) / 2, (box[1] + box[3]) / 2), label,
              font=font(size, bold), fill=fill, anchor="mm")


def line(draw, points, fill=INK, width=4):
    draw.line(points, fill=fill, width=width, joint="curve")


def character(draw, x, foot_y, scale=1.0, facing=1, step=0, mood="alert"):
    """Modular character with three headwear silhouettes and configurable colors."""
    s = scale
    p = lambda dx, dy: (int(x + dx*s), int(foot_y + dy*s))
    swing = math.sin(step * math.pi * 2) * 7
    # limbs behind body
    line(draw, [p(-10, -74), p(-19 - swing, -33), p(-25 - swing, 0)], width=max(2,int(5*s)))
    line(draw, [p(8, -74), p(18 + swing, -32), p(23 + swing, 0)], width=max(2,int(5*s)))
    line(draw, [p(-16, -111), p(-27-facing*5, -83)], width=max(2,int(4*s)))
    line(draw, [p(15, -111), p(30+facing*4, -89)], width=max(2,int(4*s)))
    draw.polygon([p(-17,-125),p(17,-125),p(23,-65),p(-23,-65)], fill=COAT, outline=INK)
    line(draw,[p(0,-123),p(0,-69)],width=max(1,int(2*s)))
    draw.ellipse([p(-27,-174),p(27,-120)],fill=FACE,outline=INK,width=max(2,int(4*s)))
    if HEADWEAR=="beanie":
        draw.pieslice([p(-29,-181),p(29,-132)],180,360,fill=HAT,outline=INK,width=max(2,int(4*s)))
        draw.ellipse([p(-10,-183),p(1,-172)],fill=HAT,outline=INK,width=max(2,int(3*s)))
    elif HEADWEAR=="cap":
        draw.pieslice([p(-28,-180),p(28,-132)],180,360,fill=HAT,outline=INK,width=max(2,int(4*s)))
        draw.polygon([p(0,-158),p(31*facing,-158),p(35*facing,-150),p(2,-151)],fill=HAT,outline=INK)
    elif HEADWEAR=="hood":
        draw.arc([p(-33,-181),p(33,-118)],170,375,fill=HAT,width=max(5,int(10*s)))
    ex = 9 if facing == 1 else -9
    draw.ellipse([p(ex-2,-149),p(ex+2,-145)],fill=INK)
    if mood == "alert":
        line(draw,[p(ex-2,-138),p(ex+6,-137)],width=max(1,int(2*s)))
    else:
        draw.arc([p(ex-6,-141),p(ex+10,-129)],0,180,fill=INK,width=max(1,int(2*s)))


@functools.lru_cache(maxsize=8)
def vignette_mask(w,h,strength):
    # Moderate corner darkening, applied after scene art and before captions.
    import numpy as np
    yy,xx=np.ogrid[:h,:w]
    xx=(xx-w/2)/(w/2);yy=(yy-h/2)/(h/2)
    arr=np.clip(((xx*xx+yy*yy)/2)**1.4,0,1)*strength
    return Image.fromarray(arr.astype("uint8"),"L")


def vignette(im, strength=70):
    w,h=im.size
    shade=Image.new("RGB",(w,h),"#16151f")
    im.paste(shade,(0,0),vignette_mask(w,h,strength))
    return im


def exterior(draw,w,h,t,shot):
    draw.rectangle((0,0,w,h),fill="#45445f")
    draw.rectangle((0,h*.58,w,h),fill="#676676")
    for i in range(13):
        bx=i*w/12
        by=h*(.38+(.07 if i%3 else 0))
        draw.rectangle((bx,by,bx+w/12+3,h*.59),fill="#3b3e55",outline=INK,width=2)
        for j in range(2):
            draw.rectangle((bx+12+j*17,by+14,bx+19+j*17,by+23),fill="#dcc28c")
    draw.ellipse((w*.83,h*.09,w*.88,h*.18),fill="#e7d8b6")
    for i in range(12):
        yy=h*(.60+i*.035)
        xx=w*(.5-i*.047)
        line(draw,[(xx,yy),(w-xx,yy)],fill="#a7a0a3",width=1)
    # A dome and antenna make this location distinct from the reference's store.
    draw.pieslice((w*.39,h*.06,w*.61,h*.36),180,360,fill="#86909a",outline=INK,width=4)
    for i in range(1,4):
        xx=w*(.39+i*.055)
        line(draw,[(xx,h*.17),(xx,h*.30)],fill="#5f6671",width=2)
    line(draw,[(w*.70,h*.30),(w*.70,h*.13)],width=3)
    draw.arc((w*.67,h*.08,w*.73,h*.16),0,180,fill=INK,width=3)
    draw.rectangle((w*.25,h*.30,w*.75,h*.65),fill="#c9b9a4",outline=INK,width=5)
    draw.rectangle((w*.25,h*.30,w*.75,h*.37),fill=TEAL,outline=INK,width=4)
    text_center(draw,(w*.25,h*.30,w*.75,h*.37),shot.get("sign","OBSERVATORY"),24,"#f0e9d9")
    draw.rectangle((w*.34,h*.38,w*.66,h*.65),fill="#363b4d",outline=INK,width=4)
    gap=min(1,max(0,(t-1.0)*1.4))*w*.045
    draw.rectangle((w*.34-gap,h*.38,w*.50-gap,h*.65),fill="#717281",outline=INK,width=2)
    draw.rectangle((w*.50+gap,h*.38,w*.66+gap,h*.65),fill="#717281",outline=INK,width=2)
    line(draw,[(w*.38-gap,h*.39),(w*.36-gap,h*.62)],fill="#a6a4ad",width=3)
    line(draw,[(w*.58+gap,h*.39),(w*.56+gap,h*.62)],fill="#a6a4ad",width=3)
    for i in range(2):
        draw.ellipse((w*(.39+i*.22),h*.39,w*(.40+i*.22),h*.41),fill="#ddcc9d")
    for xx in (.27,.70):
        draw.rectangle((w*xx,h*.43,w*(xx+.025),h*.58),fill="#626b7a",outline=INK,width=2)
    character(draw,w*.17,h*.81,1.2,1,t*.25,"alert")


def control(draw,w,h,t,shot):
    draw.rectangle((0,0,w,h),fill="#baad9f")
    draw.rectangle((0,h*.76,w,h),fill="#a49686",outline=INK,width=3)
    for i in range(12):
        x=i*w/11
        line(draw,[(x,h*.76),(w*.5+(x-w*.5)*1.8,h)],fill="#887e73",width=1)
    for y in (h*.87,h*.97):
        line(draw,[(0,y),(w,y)],fill="#897d73",width=1)
    draw.rectangle((w*.02,h*.19,w*.12,h*.43),fill="#aa8a65",outline=INK,width=3)
    text_center(draw,(w*.02,h*.20,w*.12,h*.25),"NOTICES",10)
    draw.rectangle((w*.14,h*.15,w*.75,h*.55),fill="#292934",outline=INK,width=6)
    for row in range(2):
        for col in range(4):
            x=w*(.155+col*.145); y=h*(.18+row*.17)
            draw.rectangle((x,y,x+w*.13,y+h*.145),fill="#55647b",outline=INK,width=3)
            draw.text((x+5,y+4),f"CAM {row*4+col+1:02}",font=font(9),fill="#ece9e6")
            draw.ellipse((x+w*.115,y+5,x+w*.122,y+12),fill="#dc634a" if (int(t*2)+col)%2 else "#753c3e")
            line(draw,[(x+2,y+h*.115),(x+w*.127,y+h*.115)],fill="#7b8a98",width=2)
            draw.ellipse((x+w*.065,y+h*.047,x+w*.078,y+h*.075),fill="#d5dbd7")
            line(draw,[(x+w*.071,y+h*.074),(x+w*.069,y+h*.11)],fill="#d5dbd7",width=2)
    draw.rectangle((w*.08,h*.62,w*.80,h*.80),fill="#786457",outline=INK,width=4)
    character(draw,w*.56,h*.91,1.35,-1,0,"alert")
    draw.rectangle((w*.84,h*.18,w*.95,h*.56),fill="#b8bab5",outline=INK,width=4)
    draw.rectangle((w*.88,h*.24,w*.92,h*.30),fill="#cc6449",outline=INK,width=2)
    for row in range(5):
        for col in range(2):
            x=w*(.862+col*.035);y=h*(.335+row*.037)
            draw.rectangle((x,y,x+w*.025,y+h*.021),fill="#56575a",outline=INK,width=1)


def corridor(draw,w,h,t,shot):
    draw.rectangle((0,0,w,h),fill="#b9aaa0")
    draw.polygon([(0,0),(w,0),(w*.63,h*.37),(w*.37,h*.37)],fill="#626174")
    draw.polygon([(0,h),(w,h),(w*.63,h*.37),(w*.37,h*.37)],fill="#b0a39a")
    for k in range(6):
        p=k/6
        lx=w*(.37*(1-p)); rx=w-lx
        y=h*(.37+(1-p)*.55)
        line(draw,[(lx,y),(rx,y)],fill="#867b76",width=2)
    for side in [-1,1]:
        for i in range(7):
            z=i/7
            yy=h*(.40+z*.39)
            xx=w*(.5+side*(.13+z*.37))
            draw.rectangle((xx-10,yy-24,xx+10,yy+25),fill="#766c70",outline=INK,width=2)
    draw.rectangle((w*.43,h*.32,w*.57,h*.51),fill="#314354",outline=INK,width=4)
    draw.ellipse((w*.49,h*.40,w*.52,h*.47),fill="#e6c88c")
    character(draw,w*.50+math.sin(t*2)*w*.025,h*.83,1.45,1,t*.9,"alert")


def diagram(draw,w,h,t,shot):
    draw.rectangle((0,0,w,h),fill=CREAM)
    headline=shot.get("headline","THE PLAN")
    text_center(draw,(w*.08,h*.08,w*.92,h*.22),headline,42)
    draw.rounded_rectangle((w*.17,h*.32,w*.83,h*.69),radius=8,fill="#fff2de",outline=INK,width=4)
    for i in range(3):
        if t < i*.65: continue
        x=w*(.29+i*.21)
        draw.ellipse((x-35,h*.41,x+35,h*.53),fill=[TEAL,GOLD,PURPLE][i],outline=INK,width=4)
        draw.rectangle((x-22,h*.54,x+22,h*.62),fill="#b8aba0",outline=INK,width=2)
        text_center(draw,(x-45,h*.64,x+45,h*.68),["LISTEN","COUNT","MOVE"][i],16)
    text_center(draw,(w*.20,h*.77,w*.80,h*.85),shot.get("subline","Three signals. One decision."),24,fill="#827064",bold=False)


def policy(draw,w,h,t,shot):
    draw.rectangle((0,0,w,h),fill="#ad9985")
    for y in range(0,h,48):
        line(draw,[(0,y),(w,y)],fill="#a18a77",width=2)
    left,top,right,bottom=w*.22,h*.16,w*.78,h*.82
    draw.rectangle((left+8,top+9,right+8,bottom+9),fill="#806d5e")
    draw.rectangle((left,top,right,bottom),fill="#fff1d9",outline=INK,width=5)
    draw.rectangle((left,top,right,top+h*.13),fill=TEAL,outline=INK,width=4)
    text_center(draw,(left,top,right,top+h*.13),shot.get("label","NEW OBSERVATORY RULE"),23,"#f7e6d5")
    text_center(draw,(left+20,top+h*.18,right-20,top+h*.44),shot.get("rule","Wait for the third knock."),30)
    text_center(draw,(left+20,bottom-h*.13,right-20,bottom-h*.05),shot.get("footnote","Effective tonight"),15,"#837468",False)


def day_card(draw,w,h,t,shot):
    draw.rectangle((0,0,w,h),fill="#231f28")
    text_center(draw,(0,0,w,h),shot.get("label","DAY 1"),int(h*.13),CREAM)


@functools.lru_cache(maxsize=16)
def light_overlay(w,h,kind):
    lights=Image.new("RGBA",(w,h),(0,0,0,0))
    d=ImageDraw.Draw(lights)
    if kind=="exterior": points=[(.37,.45,.12),( .63,.45,.12)]
    elif kind=="control": points=[(.45,.31,.22)]
    elif kind=="corridor": points=[(.5,.45,.14)]
    else: points=[]
    for xx,yy,r in points:
        d.ellipse(((xx-r)*w,(yy-r)*h,(xx+r)*w,(yy+r)*h),fill=(255,226,177,44))
    return lights.filter(ImageFilter.GaussianBlur(max(6,w//35)))


@functools.lru_cache(maxsize=8)
def paper_texture(w,h):
    import numpy as np
    rng=np.random.default_rng(23)
    alpha=rng.integers(0,9,(h,w),dtype=np.uint8)
    texture=Image.new("RGBA",(w,h),(51,38,28,0))
    texture.putalpha(Image.fromarray(alpha,"L"))
    return texture


SCENES={"exterior":exterior,"control":control,"corridor":corridor,"diagram":diagram,"policy":policy,"day_card":day_card}


def render_frame(project,t,w,h):
    shot=next((s for s in project["shots"] if s["start"]<=t<s["end"]),project["shots"][-1])
    im=Image.new("RGB",(w,h),CREAM)
    d=ImageDraw.Draw(im)
    SCENES[shot["type"]](d,w,h,t-shot["start"],shot)
    im=Image.alpha_composite(im.convert("RGBA"),light_overlay(w,h,shot["type"]))
    im=Image.alpha_composite(im,paper_texture(w,h)).convert("RGB")
    if shot["type"]!="diagram": vignette(im,65)
    d=ImageDraw.Draw(im)
    cue=next((c for c in project.get("captions",[]) if c["start"]<=t<c["end"]),None)
    if cue:
        label=cue["text"].upper()
        size=min(42,max(23,int(w/(max(9,len(label))*1.6))))
        cx=w/2; cy=h*.84
        for ox,oy in [(-2,0),(2,0),(0,-2),(0,2)]:
            d.text((cx+ox,cy+oy),label,font=font(size),anchor="mm",fill="#251e23")
        d.text((cx,cy),label,font=font(size),anchor="mm",fill="#f7e7d9",stroke_width=2,stroke_fill=INK)
    return im


def validate(project):
    required=["fps","width","height","duration","shots"]
    for k in required:
        if k not in project: raise ValueError(f"missing {k}")
    if project["fps"]<=0 or project["width"]<=0 or project["height"]<=0: raise ValueError("invalid dimensions/fps")
    previous=0.0
    for shot in project["shots"]:
        if shot["type"] not in SCENES: raise ValueError(f"unknown scene type: {shot['type']}")
        if abs(shot["start"]-previous)>.001 or shot["end"]<=shot["start"]: raise ValueError("shots must tile timeline with no gaps")
        previous=shot["end"]
    if abs(previous-project["duration"])>.001: raise ValueError("shots must end at duration")
    cue_end=0.0
    for cue in sorted(project.get("captions",[]),key=lambda c:c["start"]):
        if not 0<=cue["start"]<cue["end"]<=project["duration"]: raise ValueError("caption timing outside duration")
        if len(cue["text"])>30: raise ValueError("caption too long; split into shorter cues")
        if cue["start"]<cue_end: raise ValueError("captions overlap")
        cue_end=cue["end"]
    if project.get("character",{}).get("headwear","beanie") not in ("beanie","cap","hood","none"):
        raise ValueError("character.headwear must be beanie, cap, hood or none")


def configure(project):
    global INK, CREAM, TEAL, GOLD, PURPLE, SLATE, COAT, HAT, FACE, HEADWEAR
    palette=project.get("palette",{})
    for key in ("INK","CREAM","TEAL","GOLD","PURPLE","SLATE"):
        if key.lower() in palette:
            value=palette[key.lower()]
            if not isinstance(value,str) or len(value)!=7 or not value.startswith("#"):
                raise ValueError(f"palette.{key.lower()} must be #RRGGBB")
            globals()[key]=value
    char=project.get("character",{})
    COAT=char.get("coat",GOLD); HAT=char.get("hat",PURPLE); FACE=char.get("face","#f3eadf")
    HEADWEAR=char.get("headwear","beanie")


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("project",type=Path)
    ap.add_argument("--out",type=Path,required=True)
    ap.add_argument("--audio",type=Path,help="pre-recorded narration/music mix, aligned to timeline")
    ap.add_argument("--poster",type=Path,help="save representative still")
    args=ap.parse_args()
    project=json.loads(args.project.read_text(encoding="utf8")); validate(project); configure(project)
    if args.audio:
        if not args.audio.is_file(): raise FileNotFoundError(args.audio)
        probe=subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1",str(args.audio)],capture_output=True,text=True,check=True)
        actual=float(probe.stdout.strip())
        if abs(actual-project["duration"])>1.0:
            raise ValueError(f"audio duration {actual:.2f}s differs from timeline {project['duration']:.2f}s by more than 1s")
    w,h,fps=project["width"],project["height"],project["fps"]
    args.out.parent.mkdir(parents=True,exist_ok=True)
    cmd=["ffmpeg","-hide_banner","-loglevel","error","-y","-f","rawvideo","-pix_fmt","rgb24","-s",f"{w}x{h}","-r",str(fps),"-i","-"]
    if args.audio: cmd += ["-i",str(args.audio),"-map","0:v:0","-map","1:a:0","-af","apad","-shortest"]
    else: cmd += ["-f","lavfi","-i","anullsrc=channel_layout=stereo:sample_rate=48000","-map","0:v:0","-map","1:a:0","-shortest"]
    cmd += ["-c:v","libx264","-preset","veryfast","-crf","20","-pix_fmt","yuv420p","-c:a","aac","-b:a","160k","-movflags","+faststart",str(args.out)]
    proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    try:
        n=round(project["duration"]*fps)
        for i in range(n):
            frame=render_frame(project,i/fps,w,h)
            if args.poster and i==round(n*.45):
                args.poster.parent.mkdir(parents=True,exist_ok=True);frame.save(args.poster)
            proc.stdin.write(frame.tobytes())
        proc.stdin.close()
        code=proc.wait()
        if code: raise RuntimeError(f"ffmpeg failed: {code}")
    except Exception:
        proc.kill(); raise
    print(args.out)


if __name__=="__main__": main()
