import json,os
from pathlib import Path
import sherpa_onnx
import soundfile as sf

root=Path(__file__).resolve().parents[1]
name=os.environ.get('MODEL','tiny')
model=root/f'work/sherpa-onnx-whisper-{name}'
encoder=model/f'{name}-encoder.int8.onnx'
if not encoder.exists(): encoder=model/f'{name}-encoder.onnx'
rec=sherpa_onnx.OfflineRecognizer.from_whisper(str(encoder),str(model/f'{name}-decoder.int8.onnx'),str(model/f'{name}-tokens.txt'),language='pt',num_threads=3,enable_segment_timestamps=True)
audio,sr=sf.read(root/'work/audio.wav',dtype='float32')
items=[]
for start in range(0,len(audio),sr*25):
    stream=rec.create_stream()
    stream.accept_waveform(sr,audio[start:start+sr*25])
    rec.decode_stream(stream)
    r=stream.result
    result={'text':r.text,'tokens':r.tokens,'timestamps':r.timestamps,'segment_timestamps':r.segment_timestamps,'segment_durations':r.segment_durations,'segment_texts':r.segment_texts}
    result['offset']=start/sr
    items.append(result)
    print(start/sr,result,flush=True)
    (root/f'work/transcript-{name}.json').write_text(json.dumps(items,ensure_ascii=False,indent=2))
