"""Mall episode. Deterministic illustrated scenes, poses, camera, audio and captions."""
import sys,json,math,random,subprocess,functools,bisect,os
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageFilter
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
import skill_render as skill
W,H=1280,720
INK='#2e2726'; CREAM='#f8e5c6'; TEAL='#376f70'
F='/usr/share/fonts/truetype/dejavu/DejaVuSans'
@functools.lru_cache(100)
def font(n,b=True): return ImageFont.truetype(F+('-Bold' if b else '')+'.ttf',n)
def label(d,xy,text,n=26,color=INK,anchor='mm'):
    d.text(xy,text,font=font(n),fill=color,anchor=anchor)
def rect(d,b,fill,outline=INK,width=3): d.rectangle(b,fill=fill,outline=outline,width=width)
def path(d,pts,fill=INK,width=3): d.line(pts,fill=fill,width=width,joint='curve')
def glass(d,b):
    rect(d,b,'#687181');x,y,r,s=b
    d.polygon([(x+15,y+5),(x+65,y+5),(x+30,s-5),(x+5,s-5)],fill='#7b8291')
def shop(d,x,y,w,h,name,style=0):
    rect(d,(x,y,x+w,y+h),'#a8a092',width=5)
    rect(d,(x+5,y+5,x+w-5,y+44),['#3f7474','#785f71','#a87954'][style%3])
    label(d,(x+w/2,y+24),name,19,'#eee4d2')
    glass(d,(x+7,y+48,x+w-7,y+h-5))
    for j in range(3):
        xx=x+22+j*(w-30)/3
        if style==1:
            d.ellipse((xx,y+h*.52,xx+20,y+h*.52+20),fill='#c6b8a0',outline=INK,width=2)
            d.polygon([(xx-2,y+h*.52+24),(xx+22,y+h*.52+24),(xx+30,y+h*.85),(xx-9,y+h*.85)],fill=['#9c735f','#a8a18c','#677e7c'][j],outline=INK)
        else:
            for k in range(3):rect(d,(xx,y+70+k*30,xx+25,y+93+k*30),['#b99778','#8e9986','#c5b39b'][(j+k)%3],width=1)
    for xx in [x+w/2]:path(d,[(xx,y+48),(xx,y+h)],width=3)
def tiled_floor(d,y=510):
    rect(d,(0,y,W,H),'#b5a58f',width=0)
    for xx in range(-800,2100,160):path(d,[(640+(xx-640)*.3,y),(xx,720)],'#938779',1)
    for yy in [y+25,y+63,y+110,y+165]:path(d,[(0,yy),(1280,yy)],'#938779',1)
def railing(d,y):
    rect(d,(0,y,W,y+12),'#6c615a')
    for x in range(0,W,58):path(d,[(x,y+10),(x,y+65)],'#584f4a',3)
    path(d,[(0,y+65),(1280,y+65)],width=3)
def shelves(d,x,y,w,h):
    rect(d,(x,y,x+w,y+h),'#837769')
    for row in range(4):
        yy=y+15+row*(h-20)/4
        for j in range(6):
            xx=x+10+j*(w-20)/6
            rect(d,(xx,yy,xx+(w-25)/6-4,yy+30),['#a67d5d','#b19a79','#8a8c7e'][(j+row)%3],width=1)
        path(d,[(x,yy+35),(x+w,yy+35)],width=4)
@functools.lru_cache(40)
def bg(kind,night=False):
    im=Image.new('RGB',(W,H),'#b3a494');d=ImageDraw.Draw(im)
    if kind in ('atrium','escalator','food','pharmacy','toy','furniture'):
        rect(d,(0,0,W,160),'#595764',width=0)
        for x in range(-150,1400,230):
            d.polygon([(x,0),(x+160,0),(x+110,95),(x-10,95)],fill='#8f8c92',outline=INK)
        rect(d,(0,145,W,510),'#baae9e',width=3)
        tiled_floor(d)
        names={'atrium':['MODA','FARMÁCIA','BRINQUEDOS'],'food':['CAFÉ','LANCHES','SUCOS'],'toy':['LIVROS','BRINQUEDOS','PRESENTES'],'pharmacy':['FARMÁCIA','SAÚDE','PERFUMARIA'],'furniture':['QUARTO','CASA & CONFORTO','SALA'],'escalator':['CINEMA','MODA','CAFÉ']}[kind]
        for i in range(3):shop(d,20+i*427,170,385,335,names[i],i)
        if kind in ('atrium','escalator'):
            for i in range(5):shop(d,i*260,30,240,110,['MODA','TÊNIS','ÓTICA','LIVROS','JOIAS'][i],i)
            railing(d,145)
            if kind=='escalator':
                d.polygon([(350,510),(760,190),(900,190),(490,530)],fill='#73706c',outline=INK)
                for i in range(19):
                    x=365+i*22;y=505-i*17
                    path(d,[(x,y),(x+115,y)],'#aaa59b',3)
                path(d,[(339,477),(750,157),(910,157)],width=9)
                path(d,[(493,533),(910,207)],width=8)
            else:
                d.ellipse((425,520,850,640),fill='#837d78',outline=INK,width=5)
                d.ellipse((450,530,825,603),fill='#748c91',outline=INK,width=3)
                rect(d,(615,435,662,565),'#a59b88');d.ellipse((560,422,714,460),fill='#b8aa92',outline=INK,width=3)
        if kind=='food':
            for x,y in [(180,590),(560,630),(990,575)]:
                rect(d,(x-55,y-55,x+55,y-40),'#b4987e');path(d,[(x,y-40),(x,y+25)],width=5)
                for dx in (-85,85):rect(d,(x+dx-20,y-18,x+dx+20,y),'#778688');path(d,[(x+dx,y),(x+dx,y+35)],width=3)
        if kind=='furniture':
            for x,y in [(150,540),(560,590),(920,540)]:
                rect(d,(x,y-48,x+235,y+70),'#6d6262',width=4)
                rect(d,(x+5,y-65,x+230,y+30),'#d8ccae',width=3)
                rect(d,(x+12,y-58,x+95,y-20),'#eee1c5',width=2)
                path(d,[(x+110,y-60),(x+110,y+30)],'#9e927f',2)
        if kind=='toy':
            for x in range(435,815,22):path(d,[(x,214),(x,500)],'#55514d',3)
        if kind=='pharmacy':label(d,(640,245),'+',65,'#d8dfbd')
    elif kind in ('service','workshop','pump','laundry','loading'):
        rect(d,(0,0,W,510),'#aa9887',width=0);tiled_floor(d)
        for y in range(60,510,55):path(d,[(0,y),(W,y)],'#968979',1)
        for x in range(70,1200,150):path(d,[(x,0),(x,65),(x+80,65)],'#5a5653',5)
        rect(d,(535,180,750,510),'#58575b',width=5)
        rect(d,(552,196,732,505),'#797a78',width=3)
        label(d,(640,155),{'pump':'BOMBAS • ÁGUA','workshop':'MANUTENÇÃO','laundry':'ANTIGA LAVANDERIA','loading':'SAÍDA DE CARGA'}.get(kind,'SERVIÇO • MANTENHA FECHADO'),22,'#eee4c9')
        rect(d,(680,335,714,352),'#c4ae79',width=2)
        if kind=='workshop':
            shelves(d,65,205,340,285);rect(d,(850,350,1230,510),'#756052',width=4)
            for x in range(890,1190,65):path(d,[(x,230),(x,325)],'#5b5650',6);d.ellipse((x-8,220,x+8,240),outline=INK,width=3)
        elif kind=='pump':
            for x in [120,970]:
                rect(d,(x,220,x+180,510),'#829592',width=5)
                d.ellipse((x,200,x+180,240),fill='#a0aaa0',outline=INK,width=3)
                path(d,[(x+90,225),(x+90,120),(600,120)],'#546e73',14)
            rect(d,(828,360,894,500),'#9e694b');d.ellipse((830,345,892,380),fill='#bf9e71',outline=INK,width=3)
        elif kind=='loading':
            rect(d,(400,100,910,510),'#6e7278',width=6)
            for y in range(110,505,20):path(d,[(410,y),(900,y)],'#494a50',2)
            for x in [70,975]:shelves(d,x,310,225,200)
            d.polygon([(460,510),(860,510),(1070,720),(220,720)],fill='#776a5d',outline=INK)
        else:
            for x in [60,910]:rect(d,(x,240,x+265,440),'#8c8881',width=4)
            for x in [130,980]:d.ellipse((x,285,x+120,405),fill='#545c60',outline=INK,width=4)
    elif kind in ('cinema','projection','security'):
        rect(d,(0,0,W,H),'#625b64',width=0);tiled_floor(d,565)
        if kind=='cinema':
            rect(d,(195,60,1085,320),'#d5cbb6',width=12)
            label(d,(640,160),'SALA 04',35,'#a99c86')
            for row in range(3):
                for col in range(11):
                    x=40+col*116;y=400+row*86
                    d.rounded_rectangle((x,y,x+87,y+115),14,fill='#765156',outline=INK,width=4)
        else:
            rect(d,(230,80,1060,390),'#302e36',width=6)
            for i in range(8):
                x=245+i%4*201;y=97+i//4*143
                rect(d,(x,y,x+180,y+120),'#74808c',width=3)
                label(d,(x+40,y+15),f'CAM {i+1:02}',11,'#e4dfcf')
                for j in range(2):path(d,[(x,y+80+j*16),(x+180,y+80+j*16)],'#68717b',1)
            rect(d,(150,430,1130,575),'#806a59',width=5)
            for x in [320,750]:rect(d,(x,401,x+100,430),'#c4c0b0',width=3)
    elif kind in ('roof','street','exterior'):
        rect(d,(0,0,W,H),'#33354e',width=0)
        for i in range(19):
            x=i*76;y=250-(i*43)%120
            rect(d,(x,y,x+82,435),'#48495e',width=2)
            for j in range(4):rect(d,(x+12+j%2*30,y+20+j//2*45,x+20+j%2*30,y+35+j//2*45),'#c1af80',width=0)
        d.ellipse((1010,70,1084,144),fill='#bdbbae',outline=INK,width=3)
        rect(d,(0,420,W,H),'#77777e',width=0)
        if kind=='roof':
            rect(d,(0,400,W,455),'#9b9490',width=4)
            for x in [75,940]:
                rect(d,(x,470,x+180,580),'#8f9390',width=4)
                for y in range(480,570,15):path(d,[(x+10,y),(x+170,y)],'#5f6667',2)
            rect(d,(480,280,775,580),'#aaa496',width=5);rect(d,(530,335,730,580),'#62747a',width=4)
            label(d,(630,315),'TERRAÇO',21,'#ece4d0')
        elif kind=='exterior':
            rect(d,(90,230,1190,565),'#b9ac98',width=5)
            rect(d,(90,230,1190,295),TEAL,width=4);label(d,(640,264),'SHOPPING • GALERIA CENTRAL',32,'#eee4d0')
            for i in range(7):glass(d,(120+i*151,320,260+i*151,550))
            for x in range(-300,1500,200):path(d,[(640+(x-640)*.35,570),(x,720)],'#b3a8a2',2)
        else:
            path(d,[(0,620),(1280,620)],'#d3c3a0',4)
            rect(d,(850,305,1240,500),'#aba59b',width=5);label(d,(1040,337),'DEPÓSITO MUNICIPAL',18)
            rect(d,(100,430,490,555),'#a18e66',width=5)
            for i in range(6):glass(d,(120+i*58,445,168+i*58,490))
            for x in [165,420]:d.ellipse((x,525,x+58,583),fill='#373434',outline=INK,width=4)
    if night:
        im=Image.blend(im,Image.new('RGB',(W,H),'#15182b'),.42)
    im=skill.vignette(im,85)
    a=np.asarray(im).astype('int16');noise=np.random.default_rng(12).normal(0,1.1,(H,W,1))
    return Image.fromarray(np.clip(a+noise,0,255).astype('uint8'))

def person(d,x,y,s=1,t=0,zombie=False,who='you',walk=False,sit=False):
    # Sparse expressive faces, triangular work clothes, jointed limbs.
    skin='#93988c' if zombie else '#eee2cd';coat={'you':'#538082','Davi':'#987453','Marta':'#926a7c','Lia':'#c4a057','Rui':'#6d7869'}.get(who,'#8d897b')
    def p(a,b):return (x+a*s,y+b*s)
    sw=math.sin(t*7)*12 if walk else 0
    for k in [-1,1]:
        points=[p(k*9,-65),p(34+k*8,-60),p(36+k*8,-20),p(50+k*8,-20)] if sit else [p(k*9,-65),p(k*10+sw*k,-30),p(k*17-sw*k,0),p(k*17+9-sw*k,0)]
        path(d,points,INK,max(2,int(s*5)))
    d.polygon([p(-13,-123),p(14,-123),p(22,-61),p(-21,-61)],fill=coat,outline=INK)
    d.ellipse([p(-26,-175),p(27,-123)],fill=skin,outline=INK,width=max(2,int(4*s)))
    if who=='you':
        d.pieslice([p(-28,-183),p(29,-136)],180,360,fill='#827457',outline=INK,width=max(2,int(3*s)))
        path(d,[p(0,-159),p(40,-153)],INK,max(2,int(4*s)))
    elif who in ('Marta','Lia'):
        d.arc([p(-29,-179),p(29,-118)],165,355,fill='#574539',width=max(3,int(9*s)))
    for xx in [-8,9]:d.ellipse([p(xx-2,-152),p(xx+2,-145)],fill=INK)
    if zombie:d.ellipse([p(-6,-139),p(5,-131)],fill=INK)
    else:path(d,[p(0,-136),p(8,-135)],INK,max(1,int(2*s)))
    for k in [-1,1]:
        end=p(k*30,-110 if zombie else -80+sw*.5)
        path(d,[p(k*13,-119),p(k*19,-98),end],INK,max(2,int(s*4)))

def map_scene(d,shot,t):
    rect(d,(0,0,W,H),CREAM,width=0);label(d,(640,70),shot.get('title','O MAPA DO SHOPPING'),36)
    rect(d,(160,145,1120,575),'#ead9ba',width=5)
    names=['CINEMA','FARMÁCIA','BRINQUEDOS','MÓVEIS','BOMBAS','CARGA']
    for i,n in enumerate(names):
        x=190+i%3*310;y=180+i//3*235
        rect(d,(x,y,x+255,y+110),'#91a29a' if i%2 else '#c4a47c',width=3)
        label(d,(x+127,y+55),n,22)
    path(d,[(200,365),(1060,365)],'#526c77',10)
    if t>1:path(d,[(960,475),(1080,475),(1080,365),(660,365),(660,200)],'#a65242',6)
    label(d,(640,636),shot.get('sub','Conhecer os caminhos mantém o grupo vivo.'),24,'#7e6b5c')

def frame(shot,t):
    kind=shot['scene'];night=shot.get('night',False)
    if kind=='map':
        im=Image.new('RGB',(W,H));map_scene(ImageDraw.Draw(im),shot,t)
    elif kind=='card':
        im=Image.new('RGB',(W,H),CREAM);d=ImageDraw.Draw(im)
        label(d,(640,145),shot.get('title','DIA 01'),48)
        for i,txt in enumerate(shot.get('lines',[])):label(d,(640,300+i*85),txt,32,TEAL if i%2 else INK)
    else:
        im=bg(kind,night).copy();d=ImageDraw.Draw(im)
        action=shot.get('action','')
        if kind in ('security','projection'):
            for i in range(5):person(d,300+i*145,320,.30,t+i,True,'outro',True)
        if action=='metal':
            for i in range(7):
                x=310+i*105+math.sin(t*2+i)*23
                path(d,[(310+i*105,0),(x,110+i%3*55)],'#a2a1a2',2)
                rect(d,(x-35,110+i%3*55,x+35,180+i%3*55),'#9c9c9e',width=3)
        if action in ('door','wedge'):
            shift=math.sin(t*4)*20 if action=='door' else 0
            rect(d,(520+shift,180,700+shift,510),'#787c7c',width=4)
            rect(d,(550+shift,215,670+shift,295),'#323b43',width=3)
            if action=='wedge':d.polygon([(700,510),(750,510),(745,492)],fill='#a67c4a',outline=INK)
        if action=='water':
            for i in range(6):
                x=160+i*60
                rect(d,(x,545,x+35,610),'#7c9ba2',width=2);rect(d,(x+5,535,x+30,545),'#d1bc91',width=2)
        if action=='Lia':person(d,615,495,.67,t,who='Lia')
        if action=='Marta':
            rect(d,(460,535,730,558),'#77716d',width=3)
            for x in [490,700]:d.ellipse((x,565,x+25,590),fill=INK)
        for i in range(shot.get('dead',0)):
            xx,yy=(580+t*12,420-t*10) if kind=='escalator' else (100+i*113+math.sin(t*.3+i)*12,520+(i%2)*30)
            person(d,xx,yy,.73,t+i,True,who='outro',walk=True)
        if shot.get('group',0):
            for i in range(shot['group']):
                who=['Davi','Marta','Lia','Rui','outro'][i%5]
                person(d,280+i*130,620,1.0,t+i,False,who=who,walk=shot.get('walk',False),sit=action=='Marta' and who=='Marta')
        if shot.get('trade'):
            person(d,615,615,1.1,t,who='Rui')
            for x in range(565,720,19):path(d,[(x,325),(x,650)],'#403e3b',4)
            rect(d,(725,555,745,605),'#819ca1',width=2)
        if shot.get('you',True):person(d,shot.get('x',790)+(math.sin(t*.5)*20 if shot.get('walk') else 0),650,shot.get('scale',1.3),t,walk=shot.get('walk',False))
        if shot.get('rain'):
            for i in range(90):
                x=(i*137+t*120)%1280;y=(i*71+t*380)%720
                path(d,[(x,y),(x-5,y+23)],'#b7b8c2',1)
        if shot.get('day'):
            rect(d,(38,32,210,80),'#302c30',width=0);label(d,(124,56),shot['day'],22,'#efdfc5')
        if shot.get('title'):
            label(d,(640,630),shot['title'],52,'#f0e1c6')
    zoom=shot.get('zoom',1.03)
    z=shot.get('base_zoom',1)+(zoom-1)*min(t/max(.1,shot['end']-shot['start']),1)
    if z>1:
        ww=int(W/z);hh=int(H/z);cx=int(shot.get('cx',.5)*W);cy=int(shot.get('cy',.5)*H)
        left=max(0,min(W-ww,cx-ww//2));top=max(0,min(H-hh,cy-hh//2))
        im=im.crop((left,top,left+ww,top+hh)).resize((W,H),Image.Resampling.BILINEAR)
    return im

def caption(im,text):
    layer=Image.new('RGBA',im.size,(0,0,0,0));d=ImageDraw.Draw(layer)
    d.text((640,638),text,font=font(37),anchor='mm',fill='#eadfd5',stroke_width=7,stroke_fill='#efcfca')
    layer=layer.filter(ImageFilter.GaussianBlur(7))
    im=Image.alpha_composite(im.convert('RGBA'),layer)
    ImageDraw.Draw(im).text((640,638),text,font=font(37),anchor='mm',fill='#231f22',stroke_width=1,stroke_fill='#fff0df')
    return im.convert('RGB')

def main():
    project=json.loads((ROOT/'work/timeline.json').read_text());shots=project['shots'];fps=30
    (ROOT/'output').mkdir(exist_ok=True)
    out=Path(os.environ.get('FILM_OUT',str(ROOT/'work/revisado.mp4')))
    out.parent.mkdir(parents=True,exist_ok=True)
    cmd=['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r',str(fps),'-i','-','-i',str(ROOT/'source/narracao.mp3'),'-map','0:v','-map','1:a','-c:v','libx264','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-af','loudnorm=I=-16:TP=-1.5:LRA=11','-t',str(project['duration']),'-movflags','+faststart',str(out)]
    proc=subprocess.Popen(cmd,stdin=subprocess.PIPE);index=0
    for n in range(math.ceil(project['duration']*fps)):
        t=n/fps
        while index<len(shots)-1 and t>=shots[index]['end']:index+=1
        im=frame(shots[index],t-shots[index]['start'])
        cue=next((c for c in project['captions'] if c['start']<=t<c['end']),None)
        if cue:im=caption(im,cue['text'])
        proc.stdin.write(im.tobytes())
        if n%(fps*20)==0:print(f'{t:.0f}s / {project["duration"]:.0f}s',flush=True)
    proc.stdin.close()
    if proc.wait():raise RuntimeError('Render failed')
if __name__=='__main__':main()
