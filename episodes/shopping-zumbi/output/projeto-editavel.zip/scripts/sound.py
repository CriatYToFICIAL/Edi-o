"""Original procedural ambience and restrained narrative sound effects."""
from pathlib import Path
import numpy as np
from scipy.signal import butter,sosfilt
from scipy.io.wavfile import write
root=Path(__file__).resolve().parents[1];sr=24000;duration=381.727313
rng=np.random.default_rng(23);t=np.arange(round(sr*duration))/sr
bed=.0025*np.sin(2*np.pi*48*t)+.0017*np.sin(2*np.pi*72.15*t)
noise=sosfilt(butter(2,400,fs=sr,output='sos'),rng.normal(size=len(t)))
bed+=noise*.004
for a,b in [(181.64,203.84),(262.72,274.64)]:
    n=round((b-a)*sr);r=rng.normal(0,.008,n)
    fade=np.minimum(np.arange(n)/(sr*1.2),1)*np.minimum((n-np.arange(n))/(sr*1.2),1)
    bed[round(a*sr):round(a*sr)+n]+=r*fade
for a in [90,94,98,102,107,199,201,269,273,316]:
    d=.6;n=round(d*sr);x=np.arange(n)/sr
    impact=(.06*np.sin(2*np.pi*82*x)+rng.normal(0,.025,n))*np.exp(-x*16)
    bed[round(a*sr):round(a*sr)+n]+=impact
bed*=np.minimum(t/3,1)*np.minimum((duration-t)/3,1)
write(root/'work/ambience.wav',sr,(np.clip(bed,-1,1)*32767).astype('int16'))
