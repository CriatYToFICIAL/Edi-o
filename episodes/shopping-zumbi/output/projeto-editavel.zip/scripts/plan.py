import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
# Directed boundaries, seconds, derived from the actual recording.
beats=[
(0,'exterior',{'you':False,'title':'18:43'}),(4.8,'workshop',{}),(9,'security',{'dead':0}),(13,'atrium',{'dead':1,'walk':True}),(17,'escalator',{'dead':1}),(21,'escalator',{'you':True,'zoom':1.15}),
(25,'service',{'walk':True}),(30,'map',{'title':'TRÊS ANDARES','sub':'Muitos acessos. Poucas pessoas para vigiar.'}),(34,'workshop',{'night':True,'day':'DIA 01'}),(39,'service',{'night':True,'group':1}),(43,'projection',{'night':True,'group':4}),(48,'service',{'night':True,'walk':True,'group':2}),
(52,'food',{'night':True,'dead':3,'you':False}),(57,'atrium',{'night':True,'day':'DIA 02','dead':2}),(62,'card',{'title':'RECURSOS','lines':['ÁGUA • MÁQUINAS DE BEBIDAS','COMIDA • BOMBONIERE','SETE PESSOAS']}),(68,'cinema',{'night':True,'group':3}),(73,'map',{}),(79,'map',{'title':'AS ROTAS DO GRUPO','sub':'Cinema • Farmácia • Carga • Bombas'}),(84,'service',{'night':True,'group':1}),
(89,'service',{'night':True,'day':'DIA 04','dead':1,'action':'door'}),(95,'service',{'night':True,'dead':1,'action':'door','zoom':1.12}),(102,'service',{'night':True,'dead':1,'action':'wedge'}),(108,'card',{'title':'DIA 06','lines':['AS GARRAFAS ESTÃO VAZIAS','A FARMÁCIA FICA ALÉM DO ÁTRIO']}),(113,'pharmacy',{'night':True,'walk':True,'group':1}),(119,'toy',{'night':True,'group':1,'action':'Lia'}),(125,'toy',{'night':True,'group':1,'action':'Lia'}),(131,'service',{'night':True,'group':2,'walk':True}),
(136,'cinema',{'night':True,'day':'DIA 08','group':2}),(142,'furniture',{'night':True,'group':3}),(148,'furniture',{'night':True,'dead':2,'group':2}),(155,'furniture',{'night':False,'group':2}),(159,'pump',{'night':True,'day':'DIA 10','action':'water'}),(166,'map',{'title':'ÁGUA NO RESERVATÓRIO','sub':'Encher os recipientes no térreo.'}),(171,'projection',{'night':True,'group':1}),(176,'roof',{'night':True,'group':1}),(181,'map',{'title':'CONHECIMENTO COMPARTILHADO','sub':'O shopping começa a deixar de ser um labirinto.'}),
(186,'atrium',{'night':True,'rain':True,'day':'DIA 13','action':'metal'}),(193,'atrium',{'night':True,'dead':5,'rain':True,'action':'metal'}),(199,'service',{'night':True,'action':'door','group':2}),(205,'furniture',{'night':True,'group':3}),(211,'service',{'night':True,'group':1}),(217,'loading',{'night':True,'group':1,'day':'DIA 17'}),(223,'card',{'title':'QUATRO SOBREVIVENTES','lines':['DO OUTRO LADO DA PORTA','ELES PRECISAM DE REMÉDIO']}),(229,'pharmacy',{'night':True,'group':1}),(235,'map',{'title':'SEM ABRIR A PORTA','sub':'Podemos conversar através da grade.'}),(241,'toy',{'night':True,'group':2}),(248,'pharmacy',{'night':True,'group':2,'action':'water'}),(255,'map',{'title':'TROCA','sub':'Remédio e cuidados • Água e acesso seguro'}),
(260,'atrium',{'night':True,'rain':True,'action':'metal','day':'DIA 20'}),(267,'atrium',{'night':True,'dead':6,'action':'metal'}),(273,'service',{'night':True,'dead':3,'action':'door'}),(278,'map',{'title':'DUAS ESCOLHAS','sub':'Perder a saída de carga ou o acesso à água.'}),(285,'map',{'title':'UMA TERCEIRA PASSAGEM','sub':'A antiga lavanderia fica atrás da farmácia.'}),(292,'laundry',{'night':True,'group':2,'walk':True,'day':'DIA 22'}),(299,'laundry',{'night':True,'group':3,'action':'Marta'}),(305,'pump',{'night':True,'group':2,'action':'water'}),(311,'map',{'title':'O CAMINHO CONTINUA ABERTO','sub':'Bombas de água → Escada → Terraço'}),(316,'service',{'night':True,'dead':4,'action':'door','day':'DIA 26'}),(322,'roof',{'night':True,'group':4}),
(328,'street',{'night':True,'you':False}),(334,'street',{'night':True,'you':False,'zoom':1.14,'cx':.75}),(340,'roof',{'night':True,'group':3}),(346,'card',{'title':'ANTES DE DECIDIR','lines':['OBSERVAR A RUA','CONTAR OS MORTOS','PREPARAR O QUE PODEM CARREGAR']}),(352,'loading',{'night':True,'group':3}),(357,'map',{'title':'DIA 30','sub':'O mapa já não cabe no papelão.'}),(363,'map',{'title':'O CAMINHO ATÉ O DEPÓSITO','sub':'A escada do terraço marcada por Lia.'}),(369,'roof',{'night':True,'group':4}),(375,'loading',{'night':True,'group':4,'walk':True}),(379,'exterior',{'night':True,'you':False})]
shots=[]
for i,(start,scene,opts) in enumerate(beats):
    shot=dict(start=start,end=beats[i+1][0] if i+1<len(beats) else 381.727313,scene=scene,zoom=1.045)
    shot.update(opts);shots.append(shot)
for s in shots:
    if s['start'] in (211,):s['scene']='furniture'
    if s['start'] in (217,):s['scene']='atrium';s['group']=1;s['night']=True;s['day']='DIA 16'
    if s['start']==241:s['trade']=True;s['group']=0
    if s['start'] in (21,95,119,148,159,217,299,334):s['base_zoom']=1.20
captions=[
 (22.08,23.24,'ELE NÃO PARA.'),(65.48,67.04,'ÁGUA'),(67.04,68.36,'COMIDA'),(68.36,69.68,'SETE PESSOAS'),
 (142.96,144.68,'NINGUÉM TEM UMA RESPOSTA.'),(144.68,146.08,'VOCÊS MUDAM DE LUGAR.'),
 (188.44,190.20,'ELAS SE CHOCAM.'),(190.20,192.32,'TRÊS PISOS'),(225,226,'SOMOS QUATRO.'),(226,227.64,'PRECISAMOS DE REMÉDIO.'),
 (231.36,232.8,'UMA TROCA'),(232.8,234.28,'ESPERAR'),(238.08,240.48,'SEM ABRIR A PORTA.'),
 (262.72,265,'A CHUVA VOLTA.'),(282.56,284.9,'UMA TERCEIRA OPÇÃO'),(305.08,307,'HÁ ÁGUA.')]
(ROOT/'work/timeline.json').write_text(json.dumps({'duration':381.727313,'shots':shots,'captions':[dict(start=a,end=b,text=c) for a,b,c in captions]},ensure_ascii=False,indent=2))
