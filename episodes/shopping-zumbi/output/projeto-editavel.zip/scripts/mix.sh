#!/bin/sh
# Run after film.py and sound.py. The original voice remains the timing master.
set -eu
TASK_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
ffmpeg -y -v error -i "$TASK_DIR/work/revisado.mp4" -i "$TASK_DIR/work/ambience.wav" -filter_complex '[1:a]volume=0.7[bed];[0:a][bed]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.89:level=0[a]' -map 0:v -map '[a]' -c:v copy -c:a aac -b:a 192k -movflags +faststart "$TASK_DIR/output/shopping-zumbi-final.mp4"
