import json,csv,sys
from pathlib import Path
from PIL import Image,ImageDraw
sys.path.insert(0,str(Path(__file__).parent))
import film
root=Path(__file__).resolve().parents[1];data=json.loads((root/'work/timeline.json').read_text())
with (root/'output/storyboard.csv').open('w') as f:
    writer=csv.writer(f);writer.writerow(['inicio','fim','ambiente','dia','acao'])
    for s in data['shots']:writer.writerow([s['start'],s['end'],s['scene'],s.get('day',''),s.get('action','')])
times=[0,9.5,19,44,54,76,97,122,146,162,188,217,242,263,294,307,323,337,360,378]
sheet=Image.new('RGB',(1280,5*384),'#17171e')
for n,t in enumerate(times):
    s=next(x for x in data['shots'] if x['start']<=t<x['end'])
    im=film.frame(s,t-s['start']).resize((640,360),Image.Resampling.LANCZOS)
    x=n%2*640;y=n//2*384
    # Two sheets to keep review legible.
    if n==10:
        sheet.save(root/'output/contato-01.jpg',quality=92)
        sheet=Image.new('RGB',(1280,5*384),'#17171e')
    y=(n%10)//2*384
    sheet.paste(im,(x,y));ImageDraw.Draw(sheet).text((x+12,y+365),f'{int(t)//60:02}:{int(t)%60:02} • {s["scene"]}',font=film.font(14),fill='#f3e1c8')
sheet.save(root/'output/contato-02.jpg',quality=92)
poster=film.frame(data['shots'][3],1)
poster.save(root/'output/quadro-preview.png')
